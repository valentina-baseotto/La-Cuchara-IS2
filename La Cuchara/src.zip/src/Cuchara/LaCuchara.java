package Cuchara;

public class LaCuchara {

}
