package Cuchara;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import Utils.RoundedButton;

public class LaCuchara extends JFrame implements ActionListener {

	private JLabel userLabel, passwordLabel;
	private JTextField userTextField;
	private JPasswordField passwordField;
	private JButton loginButton, cancelButton, registerButton;

	public LaCuchara() {
		super("La Cuchara");
		initGUI();
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {
				new LaCuchara();
			}
		});

	}

	private void initGUI() {
		JPanel mainPanel = new JPanel(new GridLayout(3, 3)) {
			 @Override
	            protected void paintComponent(Graphics g) {
	                super.paintComponent(g);
	                ImageIcon image = new ImageIcon("src/Cuchara/fondo.png"); // Ruta de la imagen
	                g.drawImage(image.getImage(), 0, 0, getWidth(), getHeight(), null);
	            }
		};
		// Configuraci�n de la ventana
		setTitle("Iniciar sesi�n");
		setSize(650, 400);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);

		// Creaci�n de componentes
		userLabel = new JLabel("Usuario:");
		passwordLabel = new JLabel("Contrase�a:");
		userTextField = new JTextField();
		passwordField = new JPasswordField();
		loginButton = new RoundedButton("Ingresar", Color.GREEN);
		cancelButton = new RoundedButton("Cancelar", Color.RED);
		registerButton = new RoundedButton("Crear Cuenta", new Color(22, 146, 138));
		

		// A�adir componentes al panel
		JPanel loginPanel = new JPanel(new GridLayout(4, 1));
		JPanel usuario = new JPanel(new GridLayout(1, 2));
		JPanel password = new JPanel(new GridLayout(1, 2));
		JPanel inicio = new JPanel(new GridLayout(1, 2));
		usuario.add(userLabel);
		usuario.add(userTextField);
		password.add(passwordLabel);
		password.add(passwordField);
		inicio.add(loginButton);
		inicio.add(cancelButton);
		loginPanel.add(usuario);
		loginPanel.add(password);
		loginPanel.add(inicio);
		loginPanel.add(registerButton);
		loginPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));

		// Agregar eventos a los botones
		loginButton.addActionListener(this);
		cancelButton.addActionListener(this);
		for(int i = 0; i < 9; i++) {
			if(i == 4)
				mainPanel.add(loginPanel);
			else {

				JPanel blue = new JPanel();
				blue.setOpaque(false);
				
				mainPanel.add(blue);
			}
		}
		
		// Agregar panel a la ventana
		add(mainPanel);
		this.setBackground(new Color(70, 198, 226));

		// Hacer visible la ventana
		setVisible(true);
	}

	public void actionPerformed(ActionEvent e) {
		// Obtener informaci�n del usuario
		String user = userTextField.getText();
		String password = new String(passwordField.getPassword());

		if (e.getSource() == loginButton) {
			// Validar informaci�n de inicio de sesi�n
			if (user.equals("admin") && password.equals("1234")) {
				JOptionPane.showMessageDialog(this, "Inicio de sesi�n exitoso");
			} else {
				JOptionPane.showMessageDialog(this, "Usuario o contrase�a incorrectos");
			}
		} else if (e.getSource() == cancelButton) {
			// Cerrar ventana de inicio de sesi�n
			dispose();
		}

	}

}
