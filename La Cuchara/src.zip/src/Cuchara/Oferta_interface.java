package Cuchara;

public interface Oferta_interface {

	public String getDescripcion();
	public void setDescripcion(String descripcion);
	public String getNombre();
	public void setNombre(String nombre);
	public String getID();
	public void setID(String iD);
}
