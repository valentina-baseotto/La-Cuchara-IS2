package Locales;

public interface Local_interface {

	public String getNombre();
	public void setNombre(String nombre);
	public String getDireccion();
	public void setDireccion(String direccion);
	public String getCarta();
	public void setCarta(String carta);
	public int getTelefono();
	public void setTelefono(String telefono);
}
