package Usuarios;

import java.util.List;
import java.util.Scanner;

import Ofertas.Oferta;

public class ISAUsuario {

	private List<Usuario> usuarios;

	public boolean modify(String local) {
		int index = -1, opcion = 0;
		Scanner get = new Scanner(System.in);
		String valor;
		boolean modified = false;

		index = existe(local);
		if (index != -1) {
			do {
				System.out.print("1. Nombre");
				System.out.println("2. ID");
				System.out.println("3. Descripcion");
				System.out.print("Indique indice del valor a modificar: ");
				opcion = get.nextInt();
			} while (opcion < 1 && opcion > 3);

			switch (opcion) {
			case 1:
				System.out.print("Indique nuevo nombre(-1 para cancelar operacion): ");
				valor = get.next();
				if (valor != "-1") {
					usuarios.get(index).setName(valor);
					modified = true;
				}
				break;

			case 2:
				System.out.print("Indique nueva ID(-1 para cancelar operacion): ");
				valor = get.next();
				if (valor != "-1") {
					usuarios.get(index).setID(valor);
					modified = true;
				}
				break;

			case 3:
				System.out.print("Indique nuevo email(-1 para cancelar operacion): ");
				valor = get.next();
				if (valor != "-1") {
					usuarios.get(index).setMail(valor);
					modified = true;
				}
				break;
			case 4:
				System.out.print("Indique nuevo email(-1 para cancelar operacion): ");
				valor = get.next();
				if (valor != "-1") {
					usuarios.get(index).setPass(valor);
					modified = true;
				}
				break;
			case 5:
				System.out.print("Indique nuevo email(-1 para cancelar operacion): ");
				int phone = get.nextInt();
				if (phone != -1) {
					usuarios.get(index).setPhone(phone);
					modified = true;
				}
				break;
			}
		}
		
		get.close();
		
		return modified;
	}

	private int existe(String usuario) {
		int existe = -1, index = -1;
		
		for(Usuario i: usuarios) {
			index++;
			if(i.getID().equals(usuario))
				existe = index;
			
		}
		
		return existe;
	}
	
	public void consult(String local) {
		int index = existe(local);
		if(index != -1) {
			System.out.println("Nombre: " + usuarios.get(index).getName());
			System.out.println("ID: " + usuarios.get(index).getID());
			System.out.println("Descripcion: " + usuarios.get(index).getMail());
			System.out.println("Telefono: " + usuarios.get(index).getPhone());
			System.out.println("Contrase�a: " + usuarios.get(index).getPass());
		}
		else
			System.out.println("No existe el local.");
	}
	
	public void delete(String usuario) {
		int index = existe(usuario);
		
		if(index != -1) {
			usuarios.remove(index);
		}
	}
	
	public void create(Usuario oferta) {
		usuarios.add(oferta); 
	}
	
}
