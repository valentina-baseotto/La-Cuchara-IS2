package Usuarios;

public interface IFachadaSAUsuario {

	public boolean modify(String id);
	
	public Usuario consult(String id);
	
	public boolean delete(String id);
	
	public boolean create(Usuario usuario);
	
	public boolean login(String id, String pass);
}
