package Usuarios;

public interface Usuario_Interface {
	//Sets the user's name.
	public void setName(String name);
	
	//gets the user's name.
	public String getName();
	
	//Sets the user's mail.
	public void setMail(String mail);
	
	//gets the user's mail.
	public String getMail();
	
	//Sets the user's ID.
	public void setID(String ID);
	
	//gets the user's ID.
	public String getID();
	
	//Sets the user's phone.
	public void setPhone(int phone);
	
	//gets the user's phone.
	public int getPhone();
	
	//Sets the user's pass.
	public void setPass(String pass);
	
	//gets the user's pass.
	public String getPass();

}
