package Exceptions;

public class NullException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
