package windows;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultCellEditor;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

import Locales.Local;

import javax.swing.JTabbedPane;
import javax.swing.JTable;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JCheckBox;

import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;
import javax.swing.JSplitPane;
import javax.swing.LayoutStyle.ComponentPlacement;

public class ListaLocalesPanel extends JPanel {
	private JTable table;
	private int row=0;
	private int col=0;
	private List<Local> _locales;
	/**
	 * Create the panel.
	 */
	public ListaLocalesPanel(List<Local> locales) {
		_locales=locales;
		
		JScrollPane scrollPane = new JScrollPane();
		
		JButton btnNewButton = new JButton("Abrir Local");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LocalWindow lW = new LocalWindow(_locales.get(row));
			}
		});
		GroupLayout groupLayout = new GroupLayout(this);
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 186, GroupLayout.PREFERRED_SIZE)
							.addGap(153))
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 478, Short.MAX_VALUE)
							.addContainerGap())))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(18)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 256, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(17, Short.MAX_VALUE))
		);
		
		DefaultTableModel dft = new DefaultTableModel(new String[]{"Nombre", "Descripción", "More Info"},0);
		for (Local local : _locales) {
			String desc = local.getDescripcion().substring(0, Math.min(local.getDescripcion().length(), 18));
			if(local.getDescripcion().length()>18)
			{
				desc += "...";
			}
            Object[] fila = {local.getNombre(), desc};
            dft.addRow(fila);
		}
		table = new JTable(dft);
		table.setShowVerticalLines(false);
		table.setFont(new Font("Serif", Font.PLAIN, 10));
		
		
		

		// Agrega un oyente de eventos para detectar cuando se hace clic en una celda
		table.addMouseListener(new MouseAdapter() {
		    public void mouseClicked(MouseEvent e) {
		        row = table.getSelectedRow();
		        col = table.getSelectedColumn();
		    }
		});
		
		
		scrollPane.setViewportView(table);
		setLayout(groupLayout);
		this.add(scrollPane);

	}
}
