package Reservas;

public interface Reserva_interface {

	public String getFecha(); 
	public void setFecha(Fecha fecha); 
	public int getComensales(); 
	public void setComensales(int comensales);
	public String getID();
	public void setID(String ID);
}